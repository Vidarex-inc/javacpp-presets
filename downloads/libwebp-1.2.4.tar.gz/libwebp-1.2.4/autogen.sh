#! /bin/sh -e
exec autoreconf -fi
